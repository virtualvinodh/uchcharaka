from .Tamil import *

ConsonantMap = ConsonantMap[:]
ConsonantMap[29] = ConsonantMap[30]

SouthConsonantMap = SouthConsonantMap[:]
SouthConsonantMap[2] = ConsonantMap[26]

ModernVowelMap = [
                 'ஆ்ஃய',
                 'ஆ॒॑',
                 ]

ModernVowelSignMap =[
                    '்ஃயா',
                    'ா॒॑',
                    ]

IPAVowelMap = [
                  'அ',
                  'அ',

                  'அ',
                  'ஆ',
                  'ஆ',
                  'ஆ',

                  'இ',
                  'இ',

                  'உ',
                  'உ',
                  'ஊ',

                  'எ',
                  'எ',
                  'அ(அ)',
                  'அ(அ)',

                  'ஆ॒᳚',
                  'ஆ॒॑',

                  'ஒ',
                  'ஓ',
                  'ஒ',
                  'ஓ'
                  ]

NuktaConsonantMap =  [
                     'க',
                     'ஃக²',
                     'க³',
                     'ஃஜ',
                     'ட⁴',
                     'ட⁴',
                     'ஃப',
                     'ய'
                     ]

IPAVowelSignMap = [
                  '\u02BD',
                  '\u02BD',

                  '\u02BD',
                  'ா',
                  'ா',
                  'ா',

                  'ி',
                  'ி',

                  'ு',
                  'ு',
                  'ூ',

                  'ெ',
                  'ெ',
                  '(அ)',
                  '(அ)',

                  'ா॒᳚',
                  'ா॒॑',

                  'ொ',
                  'ோ',
                  'ொ',
                  'ோ'
                ]

IPAConsonantMap =[
                     'ட',
                     'ட²',
                     'ட³',
                     'வ·',
                     'வ',
                     'த·',
                     'த³·',
                     'ர',
                     'ஷ·',
                     'வ',
                     'ய்ஜ',
                     'ய',
                     'ஹ்ர',
                     'ஹ',
                     'ஶ·'
                      ]